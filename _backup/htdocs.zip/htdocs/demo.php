<?php

    echo "privetas";