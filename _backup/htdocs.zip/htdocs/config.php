<?php
    define ("ROOT", "");
    define ("DATA_DEFAULT_MODULE", "help");
    define ("DATA_DEFAULT_ACTION", "index");
    define ("HELP_API_PREFIX", "api_");
    define ("DB_ENGINE", "mysql");
    define ("DB_HOST", "localhost");
    define ("DB_USER", "root");
    define ("DB_PASS", "qwas");
    define ("DB_BASE", "drivers");
