<?php
class driver extends Module
{
    function is_all_params ()
    {
        if (!$this -> data -> is_param ("name")) return false;
        if (!$this -> data -> is_param ("email")) return false;
        if (!$this -> data -> is_param ("password")) return false;
        return true;
    }

    public function api_insert ()
    {
        if (!$this->is_all_params()) return;
        $query =
            "INSERT INTO users
                SET name = '" . $this->data->get("name") . "', 
                    email = '" . $this->data->get("email") . "', 
                    password = '" . $this->data->get("password") . "',
                    status = 1";
        $this->db->query($query);
        $this->answer = "User added";
    }

    public function api_login ()
    {
        if (!$this -> data -> is_param ("email")) return;
        if (!$this -> data -> is_param ("password")) return;
        $query =
            "SELECT id, name, email, status 
               FROM users 
              WHERE email = '" . $this->data->get("email") . "' 
                AND password = '" . $this->data->get("password") . "'";
        $user = $this -> db -> select ($query);
        if (!isset ($user [0] ["id"])) {
            $this -> data -> error ("Email or password incorrect");
            return;
        }
        $this -> data -> session ["user"] =
        $this -> answer = $this -> db -> select ($query);

    }
}