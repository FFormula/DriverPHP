<?php
/**
 * Model.Help
 * General info about this API
 * @author Jevgenij Volosatov
 */
class help extends Module
{
    /** Return current version of API */
    public function api_version()
    {
        $this -> answer = "0.2";
    }
}

